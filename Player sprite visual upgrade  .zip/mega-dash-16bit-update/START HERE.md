# Start here

This folder has everything needed to put the new 16-bit player (the **1a Clean** version) into Mega Dash.

## What's inside

- **The new player art**: all 22 frames, in 12 colours.
- **Code changes** so the game can use sprites with more than 3 colours. This covers the sprite file format, the build step, the sprite editor and the tests.
- **An updated CLAUDE.md** that makes 16-bit, SNES-era art the official look, with up to 15 colours per sprite. It also records that you asked Claude to draw this sheet. Claude may draw other sprites only when you ask for that specific sprite.
- **`alternates/`**: the Plated (1b) and Machined (1c) versions, in case you change your mind later.

## What you do (3 steps, all in the browser)

1. On GitHub, open **EchoJex/mega-dash** → **Add file → Upload files**. Drop in the zip **as-is** (`mega-dash-16bit-update.zip`, don't unzip it) and commit to `main`.
2. Start a Claude Code session on the repo and paste in the text from **PROMPT FOR CLAUDE CODE.md**. It unzips the file, applies the changes, rebuilds the sheet, runs the tests and pushes to `main`.
3. When it says it's pushed, open the game and **tap UPDATE** on the title screen.

Uploading the zip may start one extra APK build. That's harmless.

## Why Claude Code has to finish it

I can read your repo from here but can't push to it, and I can't run your build or tests. I made and checked every file I could. Claude Code does the last part in its own copy of the repo: rebuild, run the tests, push.

## One thing to avoid

Don't edit the player in the sprite editor until Claude Code has pushed. The editor saves to `main` on its own, and an edit made halfway through could clash with the update. Once it's pushed, the editor shows the 16-bit player in the right colours. The four pen buttons cover only the original 3 colours, so press **I** (eyedropper) to pick up any of the others.

## To switch to Plated or Machined later

Ask Claude Code: "Replace the player with the version in `alternates/plated` and rebuild." (Or `alternates/machined`.) The frames and timing are identical, so nothing else changes.
