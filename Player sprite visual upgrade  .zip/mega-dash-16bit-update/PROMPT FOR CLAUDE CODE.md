# Prompt for Claude Code

Paste everything below the line into a Claude Code session on the `mega-dash` repo.

---

The folder `mega-dash-16bit-update/` holds an approved 16-bit art upgrade for the player. It also makes the game's official look 16-bit (SNES era), with up to 15 colours per sprite. I've already approved the art and the rule change, so apply it as-is and make the repo support it. Please:

0. **Unzip it first if needed.** If the folder isn't in the repo yet, I uploaded it as `mega-dash-16bit-update.zip` at the repo root. Unzip it there with `unzip`, or `python3 -m zipfile -e mega-dash-16bit-update.zip .`. Then delete the zip. If the zip unpacks one folder deeper than expected, use the folder that contains `files/`.

1. **Copy the files in.** Copy everything in `mega-dash-16bit-update/files/` over the repo root, keeping the same paths. Then rename `CLAUDE.md.new` (now at the repo root) to `CLAUDE.md`, replacing the old one; the folder could not carry that exact filename. The edited files are:
   - Rules and records: `CLAUDE.md`, `design/TRACKER.md`
   - Sprite format: `docs/sprite-fmt.js`, `docs/nes-palette.js`
   - Sprite editor: `docs/sprite-editor.html`
   - Build: `tools/sprites-build.mjs`
   - Tests: `tests/sprites.test.js`
   - Game config: `src/config/display.js`
   - Art and its data: `design/sprites/player.sprite`, `public/sprites/player.png`, `src/data/sprite-art.json`

2. **Read what changed before building.**
   - The `.sprite` format gains an optional `palette` header line, one per colour, up to 15. `CLAUDE.md` describes it in "A SPRITE MAY DECLARE ITS OWN PALETTE" and "16-bit art direction".
   - Sprites without a `palette` header must behave and round-trip exactly as before.
   - The new `player.sprite` is 22 frames in 12 colours, every frame at `status=ready`.

3. **Build and check.** Run `npm run sprites:build`. It must regenerate `public/sprites/player.png` (528×24) and the `player` entry in `src/data/sprite-art.json` from `player.sprite`. Compare decoded pixels, not file bytes (the PNG encoders differ):
   - The rebuilt PNG must match `mega-dash-16bit-update/files/public/sprites/player.png` pixel for pixel.
   - The `player` entry must be exactly:
     - anims: idle 0–5, run 6–13, jumpRise 14, jumpApex 15, jumpFall 16, slide 17–21
     - holds: idle 40,6,40,6,30,5; run 4,4,3,4,4,4,3,4; jumps 5 each; slide 4,4,4,9,5

   Every other sheet must come out unchanged.

4. **Run the tests.** Run `npm run sprites` if `design/sprite-targets.json` needs the player's new frame list, then `npm test`. Fix anything that fails in code or tests. **Do not change the art's pixels, frame order or holds.**

5. **Check the ship gate.** Run `npm run sprites:ship`. The frames are already `ready`. Per `docs/marks.js`, that is only true once they verifiably reach the game, so confirm they do.

6. **Sweep leftover wording.** Search the rest of the repo for statements that drawn sprites are limited to "3 colours" / "three colours" / "NES palette", for example `design/GLOSSARY.md`, `docs/*.html` help text and `README.md`. Update them to match the new rule in `CLAUDE.md`. Leave rules about placeholders and role-based sprites alone; those still use three colours.

7. **Play it if you can.** Run `npm run dev` and check:
   - idle breathing and the visor blink
   - run and the three jump poses
   - slide
   - facing left
   - the hit flicker and status flashes

   Don't touch hitboxes, `playerClip`, `slideDurationFrames` or `MANIFEST.player.fps`. The art was drawn to fit them.

8. **Commit and push.** Commit to `main` with a message like "Player: 16-bit sheet; sprites may declare up to 15 colours". Push, then delete the `mega-dash-16bit-update/` folder (and the zip, if it's still there) in a follow-up commit.

If a step can't be done exactly as written, stop and tell me what's in the way rather than working around it.
